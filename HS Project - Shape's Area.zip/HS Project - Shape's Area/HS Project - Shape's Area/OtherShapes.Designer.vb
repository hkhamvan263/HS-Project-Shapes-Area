﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class OtherShapes
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btntrapezoid = New System.Windows.Forms.Button()
        Me.btnsquare = New System.Windows.Forms.Button()
        Me.lbltitle = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.btnsemicircle = New System.Windows.Forms.Button()
        Me.btnparallelogram = New System.Windows.Forms.Button()
        Me.btnellipse = New System.Windows.Forms.Button()
        Me.btndodecagon = New System.Windows.Forms.Button()
        Me.btnhendecagon = New System.Windows.Forms.Button()
        Me.btnheptagon = New System.Windows.Forms.Button()
        Me.btnrhombus = New System.Windows.Forms.Button()
        Me.btnpentagon = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.btndecagon = New System.Windows.Forms.Button()
        Me.btnoct = New System.Windows.Forms.Button()
        Me.btnhex = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'btntrapezoid
        '
        Me.btntrapezoid.Location = New System.Drawing.Point(20, 149)
        Me.btntrapezoid.Name = "btntrapezoid"
        Me.btntrapezoid.Size = New System.Drawing.Size(188, 58)
        Me.btntrapezoid.TabIndex = 5
        Me.btntrapezoid.Text = "Trapezoid"
        Me.btntrapezoid.UseVisualStyleBackColor = True
        '
        'btnsquare
        '
        Me.btnsquare.Location = New System.Drawing.Point(20, 71)
        Me.btnsquare.Name = "btnsquare"
        Me.btnsquare.Size = New System.Drawing.Size(188, 58)
        Me.btnsquare.TabIndex = 23
        Me.btnsquare.Text = "Square"
        Me.btnsquare.UseVisualStyleBackColor = True
        '
        'lbltitle
        '
        Me.lbltitle.AutoSize = True
        Me.lbltitle.Font = New System.Drawing.Font("Segoe UI", 14.1!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lbltitle.Location = New System.Drawing.Point(224, 43)
        Me.lbltitle.Name = "lbltitle"
        Me.lbltitle.Size = New System.Drawing.Size(308, 62)
        Me.lbltitle.TabIndex = 24
        Me.lbltitle.Text = "Other Shapes"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.btnsemicircle)
        Me.GroupBox1.Controls.Add(Me.btnparallelogram)
        Me.GroupBox1.Controls.Add(Me.btnellipse)
        Me.GroupBox1.Controls.Add(Me.btndodecagon)
        Me.GroupBox1.Controls.Add(Me.btnhendecagon)
        Me.GroupBox1.Controls.Add(Me.btnheptagon)
        Me.GroupBox1.Controls.Add(Me.btnrhombus)
        Me.GroupBox1.Controls.Add(Me.btnpentagon)
        Me.GroupBox1.Controls.Add(Me.Button2)
        Me.GroupBox1.Controls.Add(Me.btndecagon)
        Me.GroupBox1.Controls.Add(Me.btnoct)
        Me.GroupBox1.Controls.Add(Me.btnhex)
        Me.GroupBox1.Controls.Add(Me.btntrapezoid)
        Me.GroupBox1.Controls.Add(Me.btnsquare)
        Me.GroupBox1.Location = New System.Drawing.Point(50, 140)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(680, 511)
        Me.GroupBox1.TabIndex = 25
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Other Shapes"
        '
        'btnsemicircle
        '
        Me.btnsemicircle.Location = New System.Drawing.Point(435, 386)
        Me.btnsemicircle.Name = "btnsemicircle"
        Me.btnsemicircle.Size = New System.Drawing.Size(222, 58)
        Me.btnsemicircle.TabIndex = 36
        Me.btnsemicircle.Text = "Semicircle"
        Me.btnsemicircle.UseVisualStyleBackColor = True
        '
        'btnparallelogram
        '
        Me.btnparallelogram.Location = New System.Drawing.Point(435, 311)
        Me.btnparallelogram.Name = "btnparallelogram"
        Me.btnparallelogram.Size = New System.Drawing.Size(222, 58)
        Me.btnparallelogram.TabIndex = 35
        Me.btnparallelogram.Text = "Parallelogram"
        Me.btnparallelogram.UseVisualStyleBackColor = True
        '
        'btnellipse
        '
        Me.btnellipse.Location = New System.Drawing.Point(228, 386)
        Me.btnellipse.Name = "btnellipse"
        Me.btnellipse.Size = New System.Drawing.Size(188, 58)
        Me.btnellipse.TabIndex = 34
        Me.btnellipse.Text = "Ellipse"
        Me.btnellipse.UseVisualStyleBackColor = True
        '
        'btndodecagon
        '
        Me.btndodecagon.Location = New System.Drawing.Point(435, 232)
        Me.btndodecagon.Name = "btndodecagon"
        Me.btndodecagon.Size = New System.Drawing.Size(222, 58)
        Me.btndodecagon.TabIndex = 32
        Me.btndodecagon.Text = "Dodecagon"
        Me.btndodecagon.UseVisualStyleBackColor = True
        '
        'btnhendecagon
        '
        Me.btnhendecagon.Location = New System.Drawing.Point(435, 149)
        Me.btnhendecagon.Name = "btnhendecagon"
        Me.btnhendecagon.Size = New System.Drawing.Size(222, 58)
        Me.btnhendecagon.TabIndex = 31
        Me.btnhendecagon.Text = "Hendecagon"
        Me.btnhendecagon.UseVisualStyleBackColor = True
        '
        'btnheptagon
        '
        Me.btnheptagon.Location = New System.Drawing.Point(435, 71)
        Me.btnheptagon.Name = "btnheptagon"
        Me.btnheptagon.Size = New System.Drawing.Size(222, 58)
        Me.btnheptagon.TabIndex = 30
        Me.btnheptagon.Text = "Heptagon"
        Me.btnheptagon.UseVisualStyleBackColor = True
        '
        'btnrhombus
        '
        Me.btnrhombus.Location = New System.Drawing.Point(228, 311)
        Me.btnrhombus.Name = "btnrhombus"
        Me.btnrhombus.Size = New System.Drawing.Size(188, 58)
        Me.btnrhombus.TabIndex = 29
        Me.btnrhombus.Text = "Rhombus"
        Me.btnrhombus.UseVisualStyleBackColor = True
        '
        'btnpentagon
        '
        Me.btnpentagon.Location = New System.Drawing.Point(20, 311)
        Me.btnpentagon.Name = "btnpentagon"
        Me.btnpentagon.Size = New System.Drawing.Size(188, 58)
        Me.btnpentagon.TabIndex = 28
        Me.btnpentagon.Text = "Pentagon"
        Me.btnpentagon.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(228, 232)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(188, 58)
        Me.Button2.TabIndex = 27
        Me.Button2.Text = "Nonagon"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'btndecagon
        '
        Me.btndecagon.Location = New System.Drawing.Point(20, 232)
        Me.btndecagon.Name = "btndecagon"
        Me.btndecagon.Size = New System.Drawing.Size(188, 58)
        Me.btndecagon.TabIndex = 26
        Me.btndecagon.Text = "Decagon"
        Me.btndecagon.UseVisualStyleBackColor = True
        '
        'btnoct
        '
        Me.btnoct.Location = New System.Drawing.Point(228, 149)
        Me.btnoct.Name = "btnoct"
        Me.btnoct.Size = New System.Drawing.Size(188, 58)
        Me.btnoct.TabIndex = 25
        Me.btnoct.Text = "Octagon"
        Me.btnoct.UseVisualStyleBackColor = True
        '
        'btnhex
        '
        Me.btnhex.Location = New System.Drawing.Point(228, 71)
        Me.btnhex.Name = "btnhex"
        Me.btnhex.Size = New System.Drawing.Size(188, 58)
        Me.btnhex.TabIndex = 24
        Me.btnhex.Text = "Hexagon"
        Me.btnhex.UseVisualStyleBackColor = True
        '
        'OtherShapes
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(17.0!, 41.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 774)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.lbltitle)
        Me.Name = "OtherShapes"
        Me.Text = "Other Shapes"
        Me.GroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btntrapezoid As Button
    Friend WithEvents btnsquare As Button
    Friend WithEvents lbltitle As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents btnoct As Button
    Friend WithEvents btnhex As Button
    Friend WithEvents btnpentagon As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents btndecagon As Button
    Friend WithEvents btndodecagon As Button
    Friend WithEvents btnhendecagon As Button
    Friend WithEvents btnheptagon As Button
    Friend WithEvents btnrhombus As Button
    Friend WithEvents btnparallelogram As Button
    Friend WithEvents btnellipse As Button
    Friend WithEvents btnsemicircle As Button
End Class
