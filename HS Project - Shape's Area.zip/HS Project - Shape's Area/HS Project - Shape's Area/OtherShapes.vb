﻿Public Class OtherShapes
    Private Sub btnsquare_Click(sender As Object, e As EventArgs) Handles btnsquare.Click
        Square.Show()
    End Sub
    Private Sub btntrapezoid_Click(sender As Object, e As EventArgs) Handles btntrapezoid.Click
        Form2.Show()
    End Sub

    Private Sub btnhex_Click(sender As Object, e As EventArgs) Handles btnhex.Click

    End Sub

    Private Sub btnoct_Click(sender As Object, e As EventArgs) Handles btnoct.Click

    End Sub

    Private Sub btnheptagon_Click(sender As Object, e As EventArgs) Handles btnheptagon.Click

    End Sub

    Private Sub btnhendecagon_Click(sender As Object, e As EventArgs) Handles btnhendecagon.Click

    End Sub

    Private Sub btndodecagon_Click(sender As Object, e As EventArgs) Handles btndodecagon.Click

    End Sub

    Private Sub btnsemicircle_Click(sender As Object, e As EventArgs) Handles btnsemicircle.Click

    End Sub

    Private Sub btnparallelogram_Click(sender As Object, e As EventArgs) Handles btnparallelogram.Click

    End Sub
End Class