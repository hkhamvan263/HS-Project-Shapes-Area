﻿Public Class Pyramid

End Class