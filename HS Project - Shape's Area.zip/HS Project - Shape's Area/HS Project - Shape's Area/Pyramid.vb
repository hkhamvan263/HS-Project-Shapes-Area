﻿Public Class Pyramid
    Private Sub btnPyramidSAFormula_Click(sender As Object, e As EventArgs) Handles btnPyramidSAFormula.Click
        Dim AreaPyramid As String
        AreaPyramid = ""

        MessageBox.Show(AreaPyramid)
    End Sub
End Class